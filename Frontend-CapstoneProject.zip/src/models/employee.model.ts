export class Employee {
    id?: number = 0;
    fullname: string = '';
    location: string='';
    email: string='';
    mobile: number=0;

  }